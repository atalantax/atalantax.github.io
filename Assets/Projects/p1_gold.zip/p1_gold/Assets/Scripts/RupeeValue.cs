using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RupeeValue : MonoBehaviour
{
    public int value;
}
